# Cara menggunakan website ini?
- Clone atau download aplikasi.
- Setelah itu buka file index.html di browser.
- Setelah berhasil dibuka, maka ketikkan inputan berupa subjek, predikat, dan objek dalam bahasa sunda.
- Hasil akan muncul pada field hasil berupa valid atau error.

Contoh input:
1. abdi tumpak mobil<br>
hasil:<br>
valid valid valid
2. abdi numpak mobil<br>
hasil:<br>
valid error

program akan berhenti ketika terdeteksi kata yang error.


